package com.example.cutsilence

import android.content.Context
import android.media.*
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.log10

/** ভিডিওর অডিও ডিকোড করে কথার অংশগুলো (শুরু ms, শেষ ms) বের করে। */
object SilenceDetector {
    private const val FRAME_MS = 20
    private const val MIN_GAP_MS = 250     // এর চেয়ে ছোট বিরতি কাটবে না
    private const val PAD_MS = 80          // কথার আগে-পরে সামান্য জায়গা
    private const val MIN_SPEECH_MS = 150  // এর চেয়ে ছোট শব্দ (খচখচ) বাদ

    fun speechSegments(ctx: Context, uri: Uri, onProgress: (Int) -> Unit): List<Pair<Long, Long>> {
        val ex = MediaExtractor().apply { setDataSource(ctx, uri, null) }
        val track = (0 until ex.trackCount).first {
            ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/")
        }
        ex.selectTrack(track)
        val fmt = ex.getTrackFormat(track)
        val totalUs = fmt.getLong(MediaFormat.KEY_DURATION)
        val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(fmt, null, null, 0); codec.start()

        var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var win = sr * FRAME_MS / 1000
        val db = ArrayList<Float>()
        var acc = 0.0; var n = 0
        val info = MediaCodec.BufferInfo()
        var inDone = false; var outDone = false
        var lastPct = -1

        while (!outDone) {
            if (!inDone) {
                val i = codec.dequeueInputBuffer(5000)
                if (i >= 0) {
                    val size = ex.readSampleData(codec.getInputBuffer(i)!!, 0)
                    if (size < 0) { codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                    else { codec.queueInputBuffer(i, 0, size, ex.sampleTime, 0); ex.advance() }
                }
            }
            val o = codec.dequeueOutputBuffer(info, 5000)
            if (o >= 0) {
                val b = codec.getOutputBuffer(o)!!
                b.order(ByteOrder.LITTLE_ENDIAN); b.position(info.offset); b.limit(info.offset + info.size)
                val sh = b.asShortBuffer()
                var k = 0
                while (k < sh.limit()) {
                    val v = sh.get(k) / 32768.0
                    acc += v * v; n++
                    if (n >= win) { db.add((10 * log10(acc / n + 1e-10)).toFloat()); acc = 0.0; n = 0 }
                    k += ch
                }
                val pct = (info.presentationTimeUs * 100 / totalUs).toInt().coerceIn(0, 100)
                if (pct != lastPct) { lastPct = pct; onProgress(pct) }
                codec.releaseOutputBuffer(o, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
            } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val f = codec.outputFormat
                sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                win = sr * FRAME_MS / 1000
            }
        }
        codec.stop(); codec.release(); ex.release()
        if (db.isEmpty()) return emptyList()

        // স্বয়ংক্রিয় থ্রেশহোল্ড: নিচের শব্দ-স্তর আর কথার স্তরের মাঝামাঝি (নিচের দিকে ঝোঁকা)
        val sorted = db.sorted()
        val floor = sorted[(sorted.size * 0.10).toInt()]
        val peak = sorted[(sorted.size * 0.95).toInt()]
        val thr = floor + (peak - floor) * 0.30f

        val segs = ArrayList<Pair<Long, Long>>()
        var start = -1
        for (i in 0..db.size) {
            val speech = i < db.size && db[i] > thr
            if (speech && start < 0) start = i
            if (!speech && start >= 0) { segs.add(start * FRAME_MS.toLong() to i * FRAME_MS.toLong()); start = -1 }
        }
        // কাছাকাছি অংশ জোড়া লাগানো, ছোট অংশ বাদ, প্যাডিং
        val merged = ArrayList<Pair<Long, Long>>()
        for (s in segs) {
            if (merged.isNotEmpty() && s.first - merged.last().second < MIN_GAP_MS)
                merged[merged.size - 1] = merged.last().first to s.second
            else merged.add(s)
        }
        val totalMs = totalUs / 1000
        return merged.filter { it.second - it.first >= MIN_SPEECH_MS }
            .map { (maxOf(0L, it.first - PAD_MS)) to minOf(totalMs, it.second + PAD_MS) }
    }
}
