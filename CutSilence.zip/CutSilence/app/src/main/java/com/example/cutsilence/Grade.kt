package com.example.cutsilence

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.*
import com.google.common.collect.ImmutableList
import kotlin.math.*

/** Alight Motion XML (New_Project_Cc_xml_.xml) থেকে নেওয়া কালার গ্রেডিং। */
@OptIn(UnstableApi::class)
object Grade {
    const val ZOOM = 1.0f              // XML-এ ছিল 1.231771; ক্রপ-ইন চাইলে এটি বদলান
    private const val EXPOSURE = 0.17f // XML: exposure
    private const val GAMMA = 1.06f    // XML: gamma

    // XML-এর গ্রেডিং লেয়ারগুলো (১৯২০×১০৮০ কম্পোজিশনের মান)
    private class Layer(val cx: Float, val cy: Float, val sx: Float, val sy: Float, val opacity: Float)
    private val radial = Layer(966.332581f, 1344.786133f, 11.319650f, 20.123816f, 0.720703f)
    private val linear = Layer(966.332581f, 1344.786133f, 10.956002f, 19.477333f, 0.699219f)

    /** একটি ভিডিওর জন্য ইফেক্ট তালিকা (ভিডিওর অনুপাত অনুযায়ী ওভারলে বানায়)। */
    fun effects(ctx: Context, uri: Uri): androidx.media3.common.Effects {
        val r = MediaMetadataRetriever().apply { setDataSource(ctx, uri) }
        var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
        var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
        val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toInt() ?: 0
        r.release()
        if (rot == 90 || rot == 270) { val t = w; w = h; h = t }

        val list = mutableListOf<Effect>()
        if (ZOOM != 1.0f) list += ScaleAndRotateTransformation.Builder().setScale(ZOOM, ZOOM).build()
        list += lut()
        list += OverlayEffect(ImmutableList.of<TextureOverlay>(BitmapOverlay.createStaticBitmapOverlay(shadeBitmap(w, h))))
        return androidx.media3.common.Effects(emptyList<AudioProcessor>(), list)
    }

    // exposure + gamma → রঙের টেবিল (LUT)
    private fun lut(): Effect {
        val n = 17
        fun c(i: Int): Int {
            val v = min(1f, (i / (n - 1f)) * 2f.pow(EXPOSURE)).pow(1f / GAMMA)
            return (v * 255 + 0.5f).toInt().coerceIn(0, 255)
        }
        val cube = Array(n) { r -> Array(n) { g -> IntArray(n) { b -> (0xFF shl 24) or (c(r) shl 16) or (c(g) shl 8) or c(b) } } }
        return SingleColorLut.createFromCube(cube)
    }

    // দুটি multiply গ্রেডিয়েন্ট (ভিগনেট + নিচের দিকে হালকা অন্ধকার) → একটি কালো ওভারলে
    private fun shadeBitmap(w: Int, h: Int): Bitmap {
        val bw = 480; val bh = max(2, (480f * h / w).roundToInt())
        val px = IntArray(bw * bh)
        // radial layer box
        val rW = 200f * radial.sx; val rH = 200f * radial.sy
        val rL = radial.cx - rW / 2; val rT = radial.cy - rH / 2
        val rcx = rL + 0.504122f * rW; val rcy = rT + 0.514895f * rH
        val rad = hypot(rL + rW - rcx, rT + rH - rcy)
        // linear layer box
        val lW = 200f * linear.sx; val lH = 200f * linear.sy
        val lL = linear.cx - lW / 2; val lT = linear.cy - lH / 2
        val sx = lL + 0.516146f * lW; val sy = lT + 0.063349f * lH
        val ex = lL + 0.532178f * lW; val ey = lT + 1.042835f * lH
        val dx = ex - sx; val dy = ey - sy; val len2 = dx * dx + dy * dy
        for (y in 0 until bh) for (x in 0 until bw) {
            val fx = (x + 0.5f) / bw * 1920f; val fy = (y + 0.5f) / bh * 1080f
            val t1 = (hypot(fx - rcx, fy - rcy) / rad).coerceIn(0f, 1f)
            val f1 = 1 - radial.opacity + radial.opacity * (1 - t1)
            val t2 = (((fx - sx) * dx + (fy - sy) * dy) / len2).coerceIn(0f, 1f)
            val f2 = 1 - linear.opacity + linear.opacity * (1 + t2 * (0x88 / 255f - 1))
            val a = ((1 - f1 * f2) * 255 + 0.5f).toInt().coerceIn(0, 255)
            px[y * bw + x] = a shl 24
        }
        return Bitmap.createBitmap(px, bw, bh, Bitmap.Config.ARGB_8888)
    }
}
