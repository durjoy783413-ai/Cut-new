package com.example.cutsilence

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.*
import androidx.media3.transformer.*
import java.io.File
import java.io.FileOutputStream

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class MainActivity : ComponentActivity() {
    private val BLACK_MS = 300L  // কাটের জায়গায় কালো ইফেক্ট (১ সেকেন্ডের কম)
    private var videoUri: Uri? = null
    private lateinit var status: TextView
    private lateinit var startBtn: Button
    private lateinit var bar: ProgressBar
    private val handler = Handler(Looper.getMainLooper())

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { videoUri = uri; startBtn.isEnabled = true; status.text = "ভিডিও বাছাই হয়েছে" }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pick = Button(this).apply { text = "ভিডিও বাছাই করুন"; setOnClickListener { picker.launch("video/*") } }
        startBtn = Button(this).apply { text = "শুরু করুন"; isEnabled = false; setOnClickListener { videoUri?.let { analyze(it) } } }
        status = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER; text = "প্রস্তুত" }
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) // প্রসেসের সময় স্ক্রিন বন্ধ হবে না
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        listOf(pick, startBtn).forEach { it.textSize = 18f; it.setPadding(0, 40, 0, 40) }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(64, 64, 64, 64)
            addView(pick); addView(startBtn); addView(bar); addView(status)
        })
    }

    private fun analyze(uri: Uri) {
        startBtn.isEnabled = false
        Thread {
            try {
                val segs = SilenceDetector.speechSegments(this, uri) { p -> runOnUiThread { status.text = "কথা খোঁজা হচ্ছে: $p%"; bar.progress = p } }
                runOnUiThread { if (segs.isEmpty()) status.text = "কোনো কথা পাওয়া যায়নি" else export(uri, segs) }
            } catch (e: Exception) { runOnUiThread { status.text = "ত্রুটি: ${e.message}"; startBtn.isEnabled = true } }
        }.start()
    }

    private fun export(uri: Uri, segs: List<Pair<Long, Long>>) {
        val black = File(cacheDir, "black.png")
        if (!black.exists()) FileOutputStream(black).use {
            Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.BLACK) }
                .compress(Bitmap.CompressFormat.PNG, 100, it)
        }
        val grade = Grade.effects(this, uri)
        val items = mutableListOf<EditedMediaItem>()
        segs.forEachIndexed { i, (s, e) ->
            if (i > 0) items += EditedMediaItem.Builder(
                MediaItem.Builder().setUri(Uri.fromFile(black)).setImageDurationMs(BLACK_MS).build()
            ).setFrameRate(30).build()
            val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(s).setEndPositionMs(e).build()
            items += EditedMediaItem.Builder(MediaItem.Builder().setUri(uri).setClippingConfiguration(clip).build()).setEffects(grade).build()
        }
        val seq = EditedMediaItemSequence.Builder().addItems(items).setForceAudioTrack(true).build()
        val out = File(cacheDir, "out.mp4").apply { delete() }

        val transformer = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, result: ExportResult) { saveToGallery(out) }
                override fun onError(composition: Composition, result: ExportResult, ex: ExportException) {
                    status.text = "ত্রুটি: ${ex.message}"; startBtn.isEnabled = true
                }
            }).build()
        transformer.start(Composition.Builder(seq).build(), out.absolutePath)

        val holder = ProgressHolder()
        val poll = object : Runnable {
            override fun run() {
                if (transformer.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) {
                    status.text = "এডিট হচ্ছে: ${holder.progress}%"; bar.progress = holder.progress
                    handler.postDelayed(this, 500)
                }
            }
        }
        handler.post(poll)
    }

    private fun saveToGallery(f: File) {
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "cut_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CutSilence")
        }
        val dst = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
        contentResolver.openOutputStream(dst)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        f.delete()
        status.text = "শেষ! গ্যালারির Movies/CutSilence ফোল্ডারে সেভ হয়েছে"; startBtn.isEnabled = true
    }
}
